// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sfr_coursework1_interface_package:msg/TaskSpacePose.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "sfr_coursework1_interface_package/msg/task_space_pose.hpp"


#ifndef SFR_COURSEWORK1_INTERFACE_PACKAGE__MSG__DETAIL__TASK_SPACE_POSE__STRUCT_HPP_
#define SFR_COURSEWORK1_INTERFACE_PACKAGE__MSG__DETAIL__TASK_SPACE_POSE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sfr_coursework1_interface_package__msg__TaskSpacePose __attribute__((deprecated))
#else
# define DEPRECATED__sfr_coursework1_interface_package__msg__TaskSpacePose __declspec(deprecated)
#endif

namespace sfr_coursework1_interface_package
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct TaskSpacePose_
{
  using Type = TaskSpacePose_<ContainerAllocator>;

  explicit TaskSpacePose_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->x = 0.0;
      this->y = 0.0;
      this->phi_z = 0.0;
    }
  }

  explicit TaskSpacePose_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->x = 0.0;
      this->y = 0.0;
      this->phi_z = 0.0;
    }
  }

  // field types and members
  using _x_type =
    double;
  _x_type x;
  using _y_type =
    double;
  _y_type y;
  using _phi_z_type =
    double;
  _phi_z_type phi_z;

  // setters for named parameter idiom
  Type & set__x(
    const double & _arg)
  {
    this->x = _arg;
    return *this;
  }
  Type & set__y(
    const double & _arg)
  {
    this->y = _arg;
    return *this;
  }
  Type & set__phi_z(
    const double & _arg)
  {
    this->phi_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator> *;
  using ConstRawPtr =
    const sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sfr_coursework1_interface_package__msg__TaskSpacePose
    std::shared_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sfr_coursework1_interface_package__msg__TaskSpacePose
    std::shared_ptr<sfr_coursework1_interface_package::msg::TaskSpacePose_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TaskSpacePose_ & other) const
  {
    if (this->x != other.x) {
      return false;
    }
    if (this->y != other.y) {
      return false;
    }
    if (this->phi_z != other.phi_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const TaskSpacePose_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TaskSpacePose_

// alias to use template instance with default allocator
using TaskSpacePose =
  sfr_coursework1_interface_package::msg::TaskSpacePose_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sfr_coursework1_interface_package

#endif  // SFR_COURSEWORK1_INTERFACE_PACKAGE__MSG__DETAIL__TASK_SPACE_POSE__STRUCT_HPP_
