// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from sfr_coursework1_interface_package:msg/TaskSpacePose.idl
// generated code does not contain a copyright notice
#ifndef SFR_COURSEWORK1_INTERFACE_PACKAGE__MSG__DETAIL__TASK_SPACE_POSE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define SFR_COURSEWORK1_INTERFACE_PACKAGE__MSG__DETAIL__TASK_SPACE_POSE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "sfr_coursework1_interface_package/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "sfr_coursework1_interface_package/msg/detail/task_space_pose__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
bool cdr_serialize_sfr_coursework1_interface_package__msg__TaskSpacePose(
  const sfr_coursework1_interface_package__msg__TaskSpacePose * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
bool cdr_deserialize_sfr_coursework1_interface_package__msg__TaskSpacePose(
  eprosima::fastcdr::Cdr &,
  sfr_coursework1_interface_package__msg__TaskSpacePose * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
size_t get_serialized_size_sfr_coursework1_interface_package__msg__TaskSpacePose(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
size_t max_serialized_size_sfr_coursework1_interface_package__msg__TaskSpacePose(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
bool cdr_serialize_key_sfr_coursework1_interface_package__msg__TaskSpacePose(
  const sfr_coursework1_interface_package__msg__TaskSpacePose * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
size_t get_serialized_size_key_sfr_coursework1_interface_package__msg__TaskSpacePose(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
size_t max_serialized_size_key_sfr_coursework1_interface_package__msg__TaskSpacePose(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_coursework1_interface_package
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, sfr_coursework1_interface_package, msg, TaskSpacePose)();

#ifdef __cplusplus
}
#endif

#endif  // SFR_COURSEWORK1_INTERFACE_PACKAGE__MSG__DETAIL__TASK_SPACE_POSE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
