// generated from
// rosidl_typesupport_fastrtps_c/resource/rosidl_typesupport_fastrtps_c__visibility_control.h.in
// generated code does not contain a copyright notice

#ifndef SFR_CA7_INTERFACE_PACKAGE__MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C__VISIBILITY_CONTROL_H_
#define SFR_CA7_INTERFACE_PACKAGE__MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C__VISIBILITY_CONTROL_H_

#if __cplusplus
extern "C"
{
#endif

// This logic was borrowed (then namespaced) from the examples on the gcc wiki:
//     https://gcc.gnu.org/wiki/Visibility

#if defined _WIN32 || defined __CYGWIN__
  #ifdef __GNUC__
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_EXPORT_sfr_ca7_interface_package __attribute__ ((dllexport))
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_IMPORT_sfr_ca7_interface_package __attribute__ ((dllimport))
  #else
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_EXPORT_sfr_ca7_interface_package __declspec(dllexport)
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_IMPORT_sfr_ca7_interface_package __declspec(dllimport)
  #endif
  #ifdef ROSIDL_TYPESUPPORT_FASTRTPS_C_BUILDING_DLL_sfr_ca7_interface_package
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_ca7_interface_package ROSIDL_TYPESUPPORT_FASTRTPS_C_EXPORT_sfr_ca7_interface_package
  #else
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_ca7_interface_package ROSIDL_TYPESUPPORT_FASTRTPS_C_IMPORT_sfr_ca7_interface_package
  #endif
#else
  #define ROSIDL_TYPESUPPORT_FASTRTPS_C_EXPORT_sfr_ca7_interface_package __attribute__ ((visibility("default")))
  #define ROSIDL_TYPESUPPORT_FASTRTPS_C_IMPORT_sfr_ca7_interface_package
  #if __GNUC__ >= 4
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_ca7_interface_package __attribute__ ((visibility("default")))
  #else
    #define ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sfr_ca7_interface_package
  #endif
#endif

#if __cplusplus
}
#endif

#endif  // SFR_CA7_INTERFACE_PACKAGE__MSG__ROSIDL_TYPESUPPORT_FASTRTPS_C__VISIBILITY_CONTROL_H_
